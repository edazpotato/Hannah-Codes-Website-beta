this is the code for my brand new personal website which i plan to update daily. 

